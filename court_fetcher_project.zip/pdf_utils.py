from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from io import BytesIO
from datetime import datetime

def create_causelist_pdf(court_name, date_str, cases, highlight_case=None):
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4
    y = height - 50
    c.setFont("Helvetica-Bold", 14)
    c.drawString(40, y, f"Causelist - {court_name} - {date_str}")
    y -= 30
    c.setFont("Helvetica", 10)
    c.drawString(40, y, f"Generated: {datetime.utcnow().isoformat()} UTC")
    y -= 20
    c.setFont("Helvetica-Bold", 11)
    c.drawString(40, y, "Case Number")
    c.drawString(160, y, "Parties")
    c.drawString(420, y, "Bench")
    y -= 15
    c.setFont("Helvetica", 10)
    for entry in cases:
        if y < 70:
            c.showPage()
            y = height - 50
        case_no = str(entry.get("case_number",""))
        parties = str(entry.get("parties",""))[:60]
        bench = str(entry.get("bench",""))
        if highlight_case and highlight_case in case_no:
            c.setFillColorRGB(0.8, 0.2, 0.2)
        else:
            c.setFillColorRGB(0,0,0)
        c.drawString(40, y, case_no)
        c.drawString(160, y, parties)
        c.drawString(420, y, bench)
        y -= 14
    c.save()
    buffer.seek(0)
    return buffer.read()
