import requests
from bs4 import BeautifulSoup
import json
import time
import logging

# Selenium imports for fallback
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100 Safari/537.36"
}

def requests_get(url, params=None, data=None, method="get", timeout=15):
    for i in range(3):
        try:
            if method.lower() == "get":
                r = requests.get(url, params=params, headers=HEADERS, timeout=timeout)
            else:
                r = requests.post(url, data=data, headers=HEADERS, timeout=timeout)
            if r.status_code == 200:
                return r.text
            logger.warning("Status %s for %s (attempt %s)", r.status_code, url, i+1)
        except Exception as e:
            logger.warning("Request error %s: %s", url, e)
        time.sleep(1 + i)
    return None

def fetch_highcourt_case(case_type, case_number, year, hc_base="https://hcservices.ecourts.gov.in"):
    results = {"found": False, "parties": None, "filing_date": None, "next_hearing": None, "status": None, "judgments": [], "raw_html": None}
    search_url = f"{hc_base}/hcservices/main.php"
    html = requests_get(search_url)
    if not html:
        return fetch_with_selenium_highcourt(case_type, case_number, year, hc_base)
    results["raw_html"] = html
    if case_number in html:
        results["found"] = True
        results["parties"] = "Matched case number on HC main page (MVP)"
    return results

def fetch_with_selenium_highcourt(case_type, case_number, year, hc_base="https://hcservices.ecourts.gov.in"):
    results = {"found": False, "parties": None, "filing_date": None, "next_hearing": None, "status": None, "judgments": [], "raw_html": None}
    options = Options()
    options.add_argument("--headless=new")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    try:
        driver.get("https://hcservices.ecourts.gov.in/hcservices/main.php")
        time.sleep(2)
        body_text = driver.page_source
        results["raw_html"] = body_text
        if case_number in body_text:
            results["found"] = True
            results["parties"] = "Found case number in loaded HC page (selenium)"
    except Exception as e:
        logger.exception("Selenium HC error: %s", e)
    finally:
        driver.quit()
    return results

def fetch_district_case(case_type, case_number, year, base="https://services.ecourts.gov.in/ecourtindia_v6/"):
    results = {"found": False, "parties": None, "filing_date": None, "next_hearing": None, "status": None, "judgments": [], "raw_html": None}
    html = requests_get(base)
    if not html:
        return fetch_with_selenium_district(case_type, case_number, year, base)
    results["raw_html"] = html
    if case_number in html:
        results["found"] = True
        results["parties"] = "Matched case number on district main page (MVP)"
    return results

def fetch_with_selenium_district(case_type, case_number, year, base="https://services.ecourts.gov.in/ecourtindia_v6/"):
    results = {"found": False, "parties": None, "filing_date": None, "next_hearing": None, "status": None, "judgments": [], "raw_html": None}
    options = Options()
    options.add_argument("--headless=new")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    try:
        driver.get(base)
        time.sleep(2)
        src = driver.page_source
        results["raw_html"] = src
        if case_number in src:
            results["found"] = True
            results["parties"] = "Found on district page (selenium)"
    except Exception as e:
        logger.exception("Selenium district error: %s", e)
    finally:
        driver.quit()
    return results

def fetch_causelist_for_court(court_url_or_endpoint, date_str):
    html = requests_get(court_url_or_endpoint, params={"date": date_str})
    if not html:
        html = requests_get(court_url_or_endpoint)
    if not html:
        return []
    soup = BeautifulSoup(html, "lxml")
    cases = []
    tables = soup.find_all("table")
    for t in tables:
        headers = " ".join([th.get_text(strip=True).lower() for th in t.find_all("th")])
        if "case" in headers or "cnr" in headers or "party" in headers:
            for tr in t.find_all("tr"):
                cols = [td.get_text(strip=True) for td in tr.find_all(["td","th"])]
                if not cols or len(cols) < 2:
                    continue
                case_num = cols[0]
                parties = cols[1] if len(cols) > 1 else ""
                bench = cols[2] if len(cols) > 2 else ""
                cases.append({"case_number": case_num, "parties": parties, "bench": bench})
    if not cases:
        text = soup.get_text("\n")
        for line in text.splitlines():
            if "CNR" in line or "Case No" in line or "Case No." in line:
                parts = line.split()
                if len(parts) >= 2:
                    cases.append({"case_number": parts[1], "parties": " ".join(parts[2:])})
    return cases
