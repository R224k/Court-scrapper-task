# Court Data Fetcher — MVP

## Summary
This is an MVP web app that accepts case inputs, attempts to fetch case details and causelists from India eCourts portals, stores raw responses in SQLite, and can produce a PDF causelist. It uses FastAPI for backend, reportlab for PDF export, and BeautifulSoup + requests for scraping with Selenium fallback.

## Files
- `main.py` — FastAPI app
- `scraper.py` — scraping logic (requests + Selenium fallback)
- `models.py` — SQLAlchemy models + DB init
- `pdf_utils.py` — causelist PDF generator
- `templates/index.html` — minimal web UI
- `requirements.txt`

## Setup (local)
1. Create virtualenv & install:
   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
2. Initialize DB (the app initializes automatically on first run).
3. Run:
   ```bash
   uvicorn main:app --reload
   ```
4. Open `http://localhost:8000` and use the UI.

## How to demo
- Show entering a case (Case Type, Number, Year) and clicking Search — the app will attempt to fetch and store results (shows `found` true/false).
- Use Causelist form with a court causelist URL and date (e.g., tomorrow) and your case number — shows if your case is listed and returns a short list of parsed cases.
- Click the /api/causelist/pdf endpoint (you can POST from curl) to download a PDF of the causelist.

## Limitations & Next steps
- **Court pages vary** hugely by state/court. This project uses a *generic* approach: it tries requests+BS4 first and falls back to Selenium. For reliability, add per-court scraping modules with known endpoints and selectors.
- **CAPTCHA, rate-limiting, and JS-heavy pages**: Some sites block scraping or use dynamic APIs — Selenium may be necessary and slower.
- **Judgement download**: The demo scaffolds detection of judgment links but per-court logic required to reliably locate and download PDF files.
- **Legal & ethical**: Ensure scraping complies with each court's terms of service. If an official API exists, prefer it.
- **Production**: Add job queue (Celery/RQ) to fetch/periodically poll causelists, background tasks to generate scheduled PDFs, and authentication/UI polish.

## Deliverables suggestion
- GitHub repo with code, `requirements.txt`, `README.md` above
- Short demo screen recording (≤5 min) showing Search and Causelist check flows.
