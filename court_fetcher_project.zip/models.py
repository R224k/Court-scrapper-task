from sqlalchemy import Column, Integer, String, Text, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class CaseQuery(Base):
    __tablename__ = "case_queries"
    id = Column(Integer, primary_key=True)
    case_type = Column(String(64))
    case_number = Column(String(64))
    year = Column(String(8))
    court = Column(String(128))
    parsed = Column(Text)       # JSON string or simple text of parsed fields
    raw_response = Column(Text) # raw HTML or JSON response
    created_at = Column(DateTime(timezone=True), server_default=func.now())

def init_db(db_url="sqlite:///courtdata.db"):
    engine = create_engine(db_url, connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    return engine
