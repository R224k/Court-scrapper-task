import json
from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import models
from models import init_db, sessionmaker
from scraper import fetch_highcourt_case, fetch_district_case, fetch_causelist_for_court
from pdf_utils import create_causelist_pdf
from sqlalchemy.orm import Session
import os

DB_URL = os.environ.get("DATABASE_URL", "sqlite:///courtdata.db")
engine = init_db(DB_URL)
SessionLocal = sessionmaker(bind=engine)

app = FastAPI(title="Court Data Fetcher - MVP")
templates = Jinja2Templates(directory="templates")

app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/api/search")
def search(case_type: str = Form(...), case_number: str = Form(...), year: str = Form(...), court: str = Form("district")):
    db: Session = SessionLocal()
    try:
        if court.lower().startswith("h"):
            res = fetch_highcourt_case(case_type, case_number, year)
            court_name = "High Court (generic)"
        else:
            res = fetch_district_case(case_type, case_number, year)
            court_name = "District Court (generic)"
        cq = models.CaseQuery(case_type=case_type, case_number=case_number, year=year, court=court_name,
                              parsed=json.dumps({k:res.get(k) for k in ["found","parties","filing_date","next_hearing","status","judgments"]}),
                              raw_response=res.get("raw_html",""))
        db.add(cq)
        db.commit()
        db.refresh(cq)
        return JSONResponse({"ok": True, "result": res, "db_id": cq.id})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

@app.post("/api/causelist/check")
def check_causelist(court_url: str = Form(...), case_number: str = Form(...), date_str: str = Form(...)):
    cases = fetch_causelist_for_court(court_url, date_str)
    found = any(case_number in (c.get("case_number","") or "") for c in cases)
    return {"ok": True, "date": date_str, "found": found, "cases": cases[:300]}

@app.post("/api/causelist/pdf")
def causelist_pdf(court_name: str = Form(...), date_str: str = Form(...), court_url: str = Form(...)):
    cases = fetch_causelist_for_court(court_url, date_str)
    pdf_bytes = create_causelist_pdf(court_name, date_str, cases)
    return StreamingResponse(iter([pdf_bytes]), media_type="application/pdf", headers={"Content-Disposition": f"attachment; filename=causelist_{date_str}.pdf"})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
